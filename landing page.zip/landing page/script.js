// script.js

document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('section');
    const navBar = document.getElementById('navbar__list');

    // Generate navigation items dynamically
    sections.forEach(section => {
        const navItem = document.createElement('a');
        navItem.href = `#${section.id}`;
        navItem.textContent = section.dataset.nav;
        navItem.classList.add('menu__link');
        navBar.appendChild(navItem);

        // Smooth scrolling on click
        navItem.addEventListener('click', (e) => {
            e.preventDefault();
            section.scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Highlight active section while scrolling
    window.addEventListener('scroll', () => {
        let current = '';

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (pageYOffset >= sectionTop - 60) { // Adjust the offset as needed
                current = section.getAttribute('id');
            }
        });

        navBar.querySelectorAll('a').forEach(navItem => {
            navItem.classList.remove('active');
            if (navItem.getAttribute('href') === `#${current}`) {
                navItem.classList.add('active');
            }
        });
    });
});
